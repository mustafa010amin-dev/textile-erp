/* Office-server bridge: gives the ERP the same storage, login, uploads and downloads it had inside Claude. */
(function () {
  window.ERP_STANDALONE = true;
  const toLogin = () => { location.href = '/login.html'; };
  async function api(method, u, body, raw) {
    const r = await fetch(u, { method, headers: raw ? (raw.headers || {}) : { 'content-type': 'application/json' }, body: raw ? raw.body : body === undefined ? undefined : JSON.stringify(body) });
    if (r.status === 401) { toLogin(); throw { code: 'unauthenticated', message: 'Please log in again' }; }
    if (r.status === 403) throw { code: 'invalid_argument', message: await r.text() };
    if (!r.ok) { let t = await r.text(); try { t = JSON.parse(t); } catch (e) { t = { message: t }; } throw Object.assign({ code: 'unavailable' }, t); }
    return r.json();
  }
  let meP = null; const me = () => meP = meP || api('GET', '/api/me');

  /* ---- database ---- */
  const subs = {}; // path -> { docs: {}, cbs: Set, loaded }
  let es = null, wasDown = false;
  function snap(s) { return { docs: Object.entries(s.docs).map(([id, d]) => ({ id, data: () => d })), metadata: { fromCache: false } }; }
  function notify(p) { const s = subs[p]; if (s) s.cbs.forEach(cb => { try { cb(snap(s)); } catch (e) { console.error(e); } }); }
  async function load(p) { const s = subs[p]; const r = await api('GET', '/api/coll?path=' + encodeURIComponent(p)); s.docs = r.docs || {}; s.loaded = true; notify(p); }
  function stream() {
    if (es) return; es = new EventSource('/api/events');
    es.onmessage = ev => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } const s = subs[m.path]; if (!s || !s.loaded) return; if (m.data == null) delete s.docs[m.id]; else s.docs[m.id] = m.data; notify(m.path); };
    es.onerror = () => { wasDown = true; const c = document.getElementById('conn'); if (c) c.innerHTML = '<span class="dot"></span>Reconnecting to server…'; };
    es.onopen = () => { if (wasDown) { wasDown = false; Object.keys(subs).forEach(p => load(p).catch(() => { })); if (window.setConn) setConn(); } };
  }
  function subscribe(p, cb, err) {
    stream();
    const s = subs[p] = subs[p] || { docs: {}, cbs: new Set(), loaded: false };
    s.cbs.add(cb);
    if (s.loaded) cb(snap(s)); else load(p).catch(e => { if (err) err(e); });
    return () => s.cbs.delete(cb);
  }
  const db = {
    collection(p) {
      return {
        onSnapshot: (cb, err) => subscribe(p, cb, err),
        doc: id => ({ set: data => api('PUT', '/api/doc', { path: p, id, data }), delete: () => api('DELETE', '/api/doc?path=' + encodeURIComponent(p) + '&id=' + encodeURIComponent(id)) })
      };
    },
    doc(full) {
      const i = full.lastIndexOf('/'), p = full.slice(0, i), id = full.slice(i + 1);
      return {
        set: data => api('PUT', '/api/doc', { path: p, id, data }),
        delete: () => api('DELETE', '/api/doc?path=' + encodeURIComponent(p) + '&id=' + encodeURIComponent(id)),
        onSnapshot: (cb, err) => subscribe(p, s => { const d = s.docs.find(x => x.id === id); cb({ exists: !!d, data: () => d ? d.data() : undefined, metadata: s.metadata }); }, err)
      };
    }
  };

  /* ---- user / roles ---- */
  const user = {
    isOwner: async () => (await me()).role === 'owner',
    canEdit: async () => ['owner', 'accountant'].includes((await me()).role),
    can: async () => (await me()).role !== 'viewer'
  };

  /* ---- files ---- */
  const assets = { upload: async f => api('POST', '/api/upload', undefined, { body: f, headers: { 'content-type': f.type || 'application/octet-stream', 'x-filename': encodeURIComponent(f.name || 'file') } }) };
  const downloads = {
    save: async ({ filename, data }) => {
      const blob = data instanceof Blob ? data : new Blob([data]);
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    }
  };

  /* ---- reading customer PO PDFs with Claude (needs an API key on the server) ---- */
  const b64 = blob => new Promise(res => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.readAsDataURL(blob); });
  const sample = {
    limits: async () => ({ images: { maxCount: 8 } }),
    json: async (prompt, opts) => {
      const images = [];
      for (const im of (opts && opts.images) || []) images.push({ type: im.type || 'image/jpeg', data: await b64(im) });
      const r = await api('POST', '/api/ai', { prompt, images });
      return r.json;
    }
  };

  window.claude = {
    use: async name => {
      if (name === 'db') return db;
      if (name === 'user') return user;
      if (name === 'assets') return assets;
      if (name === 'downloads') return downloads;
      if (name === 'sample') { const m = await me(); if (!m.ai) throw { code: 'no_key', message: 'Reading PO PDFs needs a Claude API key. The owner adds it in data/settings.json on the server (see READ-ME).' }; return sample; }
      return null;
    }
  };

  /* ---- user bar ---- */
  const ROLE = { owner: 'Owner', accountant: 'Accountant', staff: 'Staff', viewer: 'View only' };
  document.addEventListener('DOMContentLoaded', async () => {
    try {
      const m = await me(); const conn = document.getElementById('conn'); if (!conn) return;
      const d = document.createElement('div'); d.className = 'foot'; d.style.cssText = 'border-top:none;padding-top:0;font-size:12px;line-height:1.7';
      d.innerHTML = `<b>${m.name.replace(/[<>&]/g, '')}</b> · ${ROLE[m.role] || m.role}<br>${m.role === 'owner' ? '<a href="/users.html">Users</a> · ' : ''}<a href="/users.html#password">Password</a> · <a href="/logout">Log out</a>`;
      conn.after(d);
    } catch (e) { }
  });
})();

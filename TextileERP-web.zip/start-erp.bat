@echo off
title Textile ERP server
cd /d "%~dp0"
where node >nul 2>nul || (echo.& echo Node.js is not installed on this computer.& echo Install the LTS version from https://nodejs.org then run this file again.& echo.& pause & exit /b)
node server.js
pause

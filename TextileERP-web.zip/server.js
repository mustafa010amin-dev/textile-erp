/* Textile ERP — office server. No extra packages needed: just Node.js 18 or newer.
   Start:  node server.js      Then open http://<this-PC>:8080 from any computer on the office network. */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os'), url = require('url');

const ROOT = __dirname, PUB = path.join(ROOT, 'public'), DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const DBDIR = path.join(DATA, 'db'), FILES = path.join(DATA, 'files'), BACKUPS = process.env.DATA_DIR ? path.join(DATA, '..', path.basename(DATA) + '-backups') : path.join(ROOT, 'backups');
[DATA, DBDIR, FILES, BACKUPS].forEach(d => fs.mkdirSync(d, { recursive: true }));

/* ---------- small JSON files ---------- */
function readJson(f, dflt) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return dflt; } }
function writeJson(f, o) { const t = f + '.tmp'; fs.writeFileSync(t, JSON.stringify(o)); fs.renameSync(t, f); }
const SETTINGS_F = path.join(DATA, 'settings.json');
if (!fs.existsSync(SETTINGS_F)) writeJson(SETTINGS_F, { port: 8080, anthropicApiKey: '', model: 'claude-sonnet-5-5', sessionDays: 30, keepBackups: 30 });
const settings = () => { const s = Object.assign({ port: 8080, anthropicApiKey: '', model: 'claude-sonnet-5-5', sessionDays: 30, keepBackups: 30 }, readJson(SETTINGS_F, {})); if (process.env.ANTHROPIC_API_KEY) s.anthropicApiKey = process.env.ANTHROPIC_API_KEY; if (process.env.PORT) s.port = +process.env.PORT; return s; };
const USERS_F = path.join(DATA, 'users.json'), SESS_F = path.join(DATA, 'sessions.json');
let users = readJson(USERS_F, []);
let sessions = readJson(SESS_F, {});
const saveUsers = () => writeJson(USERS_F, users), saveSessions = () => writeJson(SESS_F, sessions);
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64).toString('hex');
const ROLES = ['owner', 'accountant', 'staff', 'viewer'];

/* ---------- database: one file per collection, kept in memory ---------- */
const enc = p => p.replace(/[^A-Za-z0-9_\-]/g, c => c === '/' ? '~' : '_');
const colls = {}; const dirty = new Set(); let flushT = null;
function coll(p) {
  if (!colls[p]) colls[p] = readJson(path.join(DBDIR, enc(p) + '.json'), {});
  return colls[p];
}
fs.readdirSync(DBDIR).filter(f => f.endsWith('.json')).forEach(f => { const p = f.slice(0, -5).replace(/~/g, '/'); coll(p); });
function markDirty(p) { dirty.add(p); clearTimeout(flushT); flushT = setTimeout(flush, 300); }
function flush() { for (const p of dirty) writeJson(path.join(DBDIR, enc(p) + '.json'), colls[p]); dirty.clear(); }
process.on('SIGINT', () => { flush(); process.exit(0); });
process.on('SIGTERM', () => { flush(); process.exit(0); });

/* who may read / write a collection */
const isMoney = p => /^(secure|books|bookchunks)(\/|$)/.test(p);
const canRead = (role, p) => !isMoney(p) || role === 'owner' || role === 'accountant';
const canWrite = (role, p) => role !== 'viewer' && canRead(role, p);
const validPath = p => typeof p === 'string' && /^[A-Za-z0-9_\-]+(\/[A-Za-z0-9_\-]+)*$/.test(p) && p.length < 120;
const validId = id => typeof id === 'string' && /^[A-Za-z0-9_\-.]{1,120}$/.test(id);

/* ---------- live updates (server-sent events) ---------- */
const clients = new Set();
function broadcast(p, id, data) {
  const msg = `data: ${JSON.stringify({ path: p, id, data })}\n\n`;
  for (const c of clients) if (canRead(c.role, p)) c.res.write(msg);
}
setInterval(() => { for (const c of clients) c.res.write(': ping\n\n'); }, 25000);

/* ---------- daily backups ---------- */
function backupNow() {
  flush();
  const day = new Date().toISOString().slice(0, 10), dst = path.join(BACKUPS, day);
  fs.rmSync(dst, { recursive: true, force: true });
  fs.cpSync(DATA, dst, { recursive: true, filter: s => !s.endsWith('sessions.json') });
  const keep = settings().keepBackups || 30;
  fs.readdirSync(BACKUPS).filter(d => /^\d{4}-\d\d-\d\d$/.test(d)).sort().slice(0, -keep).forEach(d => fs.rmSync(path.join(BACKUPS, d), { recursive: true, force: true }));
  console.log('Backup saved:', dst);
}
setTimeout(backupNow, 5000); setInterval(backupNow, 60 * 60 * 1000);

/* ---------- helpers ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function send(res, code, body, type) { res.writeHead(code, { 'content-type': type || 'application/json', 'cache-control': 'no-store' }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); }
function readBody(req, limit) {
  return new Promise((resolve, reject) => { const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks))); req.on('error', reject); });
}
const readJsonBody = async (req, limit) => JSON.parse((await readBody(req, limit || 50e6)).toString('utf8') || '{}');
function cookies(req) { const o = {}; (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
function currentUser(req) {
  const t = cookies(req).erpsid; const s = t && sessions[t];
  if (!s || s.exp < Date.now()) return null;
  const u = users.find(x => x.u === s.u && x.active !== false);
  return u ? { u: u.u, name: u.name, role: u.role } : null;
}
const fails = {};
function serveFile(res, f) {
  fs.readFile(f, (e, b) => { if (e) return send(res, 404, 'Not found', 'text/plain'); res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' }); res.end(b); });
}

/* ---------- Claude (reads customer PO PDFs) ---------- */
async function askClaude(prompt, images) {
  const s = settings(); if (!s.anthropicApiKey) throw new Error('no_key');
  const content = (images || []).map(im => ({ type: 'image', source: { type: 'base64', media_type: im.type || 'image/jpeg', data: im.data } }));
  content.push({ type: 'text', text: prompt + '\n\nReply with the JSON object only, no other text.' });
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': s.anthropicApiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: s.model, max_tokens: 8000, messages: [{ role: 'user', content }] }) });
  const j = await r.json(); if (!r.ok) throw new Error((j.error && j.error.message) || ('API error ' + r.status));
  const text = (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
  const a = text.indexOf('{'), b = text.lastIndexOf('}'); if (a < 0 || b < a) throw new Error('invalid_json');
  return JSON.parse(text.slice(a, b + 1));
}

/* ---------- requests ---------- */
const server = http.createServer(async (req, res) => {
  try {
    const U = url.parse(req.url, true), p = decodeURIComponent(U.pathname), q = U.query;
    const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress).split(',')[0].trim();
    // first run: create the owner account
    if (!users.length && !p.startsWith('/lib/')) {
      if (p === '/api/setup' && req.method === 'POST') {
        const b = await readJsonBody(req, 1e5);
        if (process.env.SETUP_CODE && String(b.code || '').trim() !== process.env.SETUP_CODE) return send(res, 403, 'Wrong setup code', 'text/plain');
        if (!b.u || !b.pw || String(b.pw).length < 6) return send(res, 400, 'Enter a username and a password of at least 6 characters', 'text/plain');
        const salt = crypto.randomBytes(16).toString('hex');
        users.push({ u: String(b.u).trim().toLowerCase(), name: String(b.name || b.u).trim(), role: 'owner', salt, hash: hashPw(b.pw, salt), active: true, created: new Date().toISOString() }); saveUsers();
        return send(res, 200, { ok: true });
      }
      if (p === '/api/setup-info') return send(res, 200, { needCode: !!process.env.SETUP_CODE });
      return serveFile(res, path.join(PUB, 'setup.html'));
    }
    if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
    if (p === '/login.html' || p.startsWith('/lib/') || p === '/favicon.ico') return serveFile(res, path.join(PUB, p.startsWith('/lib/') ? p.replace(/\.\./g, '') : p));
    if (p === '/api/login' && req.method === 'POST') {
      const f = fails[ip] || { n: 0, until: 0 }; if (f.until > Date.now()) return send(res, 429, 'Too many wrong passwords — wait a minute', 'text/plain');
      const b = await readJsonBody(req, 1e5); const u = users.find(x => x.u === String(b.u || '').trim().toLowerCase() && x.active !== false);
      if (!u || hashPw(b.pw || '', u.salt) !== u.hash) { f.n++; if (f.n >= 5) { f.until = Date.now() + 60000; f.n = 0; } fails[ip] = f; return send(res, 401, 'Wrong username or password', 'text/plain'); }
      delete fails[ip];
      const t = crypto.randomBytes(32).toString('hex'), days = settings().sessionDays || 30;
      sessions[t] = { u: u.u, exp: Date.now() + days * 864e5 }; Object.keys(sessions).forEach(k => { if (sessions[k].exp < Date.now()) delete sessions[k]; }); saveSessions();
      const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
      res.writeHead(200, { 'set-cookie': `erpsid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${days * 86400}${secure}`, 'content-type': 'application/json' }); return res.end('{"ok":true}');
    }
    if (p === '/logout') { const t = cookies(req).erpsid; if (t) { delete sessions[t]; saveSessions(); } res.writeHead(302, { location: '/login.html', 'set-cookie': 'erpsid=; Path=/; Max-Age=0' }); return res.end(); }

    const me = currentUser(req);
    if (!me) { if (p.startsWith('/api/') || p.startsWith('/_blob/')) return send(res, 401, 'Please log in', 'text/plain'); res.writeHead(302, { location: '/login.html' }); return res.end(); }

    if (p === '/' || p === '/index.html') return serveFile(res, path.join(PUB, 'index.html'));
    if (p === '/shim.js' || p === '/users.html') return serveFile(res, path.join(PUB, p));
    if (p === '/api/me') return send(res, 200, Object.assign({ ai: !!settings().anthropicApiKey }, me));

    if (p === '/api/coll' && req.method === 'GET') {
      if (!validPath(q.path)) return send(res, 400, 'bad path', 'text/plain');
      if (!canRead(me.role, q.path)) return send(res, 403, 'Not allowed', 'text/plain');
      return send(res, 200, { docs: coll(q.path) });
    }
    if (p === '/api/doc' && (req.method === 'PUT' || req.method === 'DELETE')) {
      const b = req.method === 'PUT' ? await readJsonBody(req) : { path: q.path, id: q.id };
      if (!validPath(b.path) || !validId(b.id)) return send(res, 400, 'bad path', 'text/plain');
      if (!canWrite(me.role, b.path)) return send(res, 403, 'Not allowed', 'text/plain');
      const c = coll(b.path);
      if (req.method === 'PUT') { if (!b.data || typeof b.data !== 'object') return send(res, 400, 'no data', 'text/plain'); c[b.id] = b.data; broadcast(b.path, b.id, b.data); }
      else { delete c[b.id]; broadcast(b.path, b.id, null); }
      markDirty(b.path); return send(res, 200, { ok: true });
    }
    if (p === '/api/events') {
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' }); res.write(': hi\n\n');
      const c = { res, role: me.role }; clients.add(c); req.on('close', () => clients.delete(c)); return;
    }
    if (p === '/api/upload' && req.method === 'POST') {
      if (me.role === 'viewer') return send(res, 403, 'Not allowed', 'text/plain');
      const buf = await readBody(req, 40e6); const id = 'f' + crypto.randomBytes(12).toString('hex');
      fs.writeFileSync(path.join(FILES, id), buf);
      writeJson(path.join(FILES, id + '.meta'), { name: String(req.headers['x-filename'] || 'file'), type: String(req.headers['content-type'] || 'application/octet-stream'), by: me.u, at: new Date().toISOString() });
      return send(res, 200, { id });
    }
    if (p.startsWith('/_blob/')) {
      const id = p.slice(7); if (!validId(id) || !fs.existsSync(path.join(FILES, id))) return send(res, 404, 'Not found', 'text/plain');
      const m = readJson(path.join(FILES, id + '.meta'), {});
      res.writeHead(200, { 'content-type': m.type || 'application/octet-stream', 'content-disposition': `inline; filename="${String(m.name || id).replace(/"/g, '')}"` });
      return fs.createReadStream(path.join(FILES, id)).pipe(res);
    }
    if (p === '/api/ai' && req.method === 'POST') {
      if (me.role === 'viewer') return send(res, 403, 'Not allowed', 'text/plain');
      const b = await readJsonBody(req, 60e6);
      try { return send(res, 200, { json: await askClaude(b.prompt, b.images) }); }
      catch (e) { return send(res, 502, { code: e.message === 'no_key' ? 'no_key' : e.message === 'invalid_json' ? 'invalid_json' : 'api', message: e.message }); }
    }
    if (p === '/api/import' && req.method === 'POST') {
      if (me.role !== 'owner') return send(res, 403, 'Only the owner can restore', 'text/plain');
      const d = await readJsonBody(req, 500e6);
      if (!d || d.kind !== 'textile-erp-backup' || !d.coll) return send(res, 400, 'Not an ERP backup', 'text/plain');
      backupNow(); const stamp = path.join(BACKUPS, 'before-restore-' + Date.now()); fs.cpSync(DBDIR, stamp, { recursive: true });
      Object.keys(colls).forEach(k => { colls[k] = {}; markDirty(k); });
      Object.entries(d.coll).forEach(([pth, m]) => { if (!validPath(pth)) return; colls[pth] = m || {}; markDirty(pth); });
      if (d.config) { coll('config').main = d.config; markDirty('config'); }
      Object.entries(d.files || {}).forEach(([id, f]) => { if (!validId(id)) return; fs.writeFileSync(path.join(FILES, id), Buffer.from(f.data, 'base64')); writeJson(path.join(FILES, id + '.meta'), { name: id, type: f.type || 'application/pdf' }); });
      flush(); return send(res, 200, { ok: true });
    }
    /* users (owner only), own password */
    if (p === '/api/password' && req.method === 'POST') {
      const b = await readJsonBody(req, 1e5); const u = users.find(x => x.u === me.u);
      if (hashPw(b.old || '', u.salt) !== u.hash) return send(res, 400, 'Current password is wrong', 'text/plain');
      if (String(b.pw || '').length < 6) return send(res, 400, 'New password must be at least 6 characters', 'text/plain');
      u.salt = crypto.randomBytes(16).toString('hex'); u.hash = hashPw(b.pw, u.salt); saveUsers(); return send(res, 200, { ok: true });
    }
    if (p === '/api/users') {
      if (me.role !== 'owner') return send(res, 403, 'Only the owner manages users', 'text/plain');
      if (req.method === 'GET') return send(res, 200, users.map(x => ({ u: x.u, name: x.name, role: x.role, active: x.active !== false, created: x.created })));
      const b = await readJsonBody(req, 1e5); const name = String(b.u || '').trim().toLowerCase();
      if (!/^[a-z0-9._\-]{2,40}$/.test(name)) return send(res, 400, 'Username: letters, numbers, dot or dash', 'text/plain');
      if (b.role && !ROLES.includes(b.role)) return send(res, 400, 'Bad role', 'text/plain');
      let u = users.find(x => x.u === name);
      if (!u) { if (String(b.pw || '').length < 6) return send(res, 400, 'Password must be at least 6 characters', 'text/plain'); u = { u: name, created: new Date().toISOString(), active: true }; users.push(u); }
      if (b.name != null) u.name = String(b.name).trim() || name;
      if (b.role) { if (u.u === me.u && b.role !== 'owner') return send(res, 400, 'You cannot remove your own owner access', 'text/plain'); u.role = b.role; }
      if (b.active != null) { if (u.u === me.u && !b.active) return send(res, 400, 'You cannot disable yourself', 'text/plain'); u.active = !!b.active; if (!u.active) Object.keys(sessions).forEach(k => { if (sessions[k].u === u.u) delete sessions[k]; }); }
      if (b.pw) { if (String(b.pw).length < 6) return send(res, 400, 'Password must be at least 6 characters', 'text/plain'); u.salt = crypto.randomBytes(16).toString('hex'); u.hash = hashPw(b.pw, u.salt); }
      u.role = u.role || 'staff'; saveUsers(); saveSessions(); return send(res, 200, { ok: true });
    }
    return send(res, 404, 'Not found', 'text/plain');
  } catch (e) { console.error(e); try { send(res, 500, 'Server error: ' + e.message, 'text/plain'); } catch (e2) { } }
});
const port = settings().port || 8080;
server.listen(port, '0.0.0.0', () => {
  console.log('\n  Textile ERP is running.\n');
  console.log(`  On this computer:   http://localhost:${port}`);
  Object.values(os.networkInterfaces()).flat().filter(a => a && a.family === 'IPv4' && !a.internal).forEach(a => console.log(`  Other computers:    http://${a.address}:${port}`));
  console.log('\n  Keep this window open. Data is in the "data" folder; daily copies in "backups".\n');
});
